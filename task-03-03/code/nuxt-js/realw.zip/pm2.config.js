{
    "apps": [{
        "name": "RealWorld",
        "script": "npm",
        "args": "start"
    }]
}